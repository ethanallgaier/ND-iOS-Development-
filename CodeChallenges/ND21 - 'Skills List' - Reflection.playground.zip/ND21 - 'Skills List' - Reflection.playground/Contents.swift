//  🏔️ MTECH Code Challenge ND21: "Skills List"
//  Concept: Reflect on learning so far in the program

//  Instructions:
    //  Today is the last day of the third course. You have covered a lot of the core content of this course at this point.
    //  Use this code challenge as an opportunity to reflect.
    //  In the space below, without referring to your book, notes, or previous projects, list all of the skills and abilities you feel you've mastered since the beginning of this program.
    //  This is an opportunity to be pat yourself on the back for your learning so far!

//  ⌺ Black Diamond Challenge:
    //  Where applicable, provide code examples of the skills you've learned.

//  MARK: Student response
/*  Write your response below.
 
 Ive learned a lot of back end stuff, like how to deal with api's and being able to grab urls and bring them into my swift code and display the data.
 
 I feel like ive gotten pretty used to MVVM, i wouldnt say ive mastered it.
 
 Creating simple functions
 Creating some cool ui stuff
 createing varibale
 write code:)
 MVVM
 navigation link
 SwiftData
 Sheets
 use notes for better understanding
 debugging
 
 
 
 
 
 
 
 */
