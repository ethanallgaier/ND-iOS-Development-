
 

//WHAT TO DO



//Add animations using withAnimation, .transition, and .matchedGeometryEffect.

// addd edit
// add animatioon

//With Animation Complete
//.transition
//.matchedGeometryEffect..com
